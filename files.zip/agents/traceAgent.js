import dotenv from 'dotenv';
dotenv.config();

import { Connection, PublicKey } from '@solana/web3.js';
import { Agent } from 'juliaos';
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';

const connection = new Connection(process.env.SOLANA_RPC_URL);

const argv = yargs(hideBin(process.argv)).options({
  wallet: { type: 'string', demandOption: false },
  tx: { type: 'string', demandOption: false },
  test: { type: 'boolean', default: false }
}).argv;

const agent = new Agent();

// Fetch recent transactions for a wallet
async function fetchRecentTransactions(walletAddress) {
  const pubkey = new PublicKey(walletAddress);
  const signatures = await connection.getSignaturesForAddress(pubkey, { limit: 10 });
  const transactions = await Promise.all(
    signatures.map(sig => connection.getTransaction(sig.signature, { commitment: 'confirmed' }))
  );
  return transactions.filter(Boolean);
}

// Analyze transactions with LLM
async function analyzeWithLLM(data) {
  const prompt = `Analyze the following Solana transaction data and summarize any suspicious patterns:\n${JSON.stringify(data, null, 2)}`;
  const response = await agent.useLLM(prompt);
  return response;
}

// Optionally mock transactions for testing
function mockTransactions() {
  return [
    {
      slot: 12345678,
      transaction: {
        signatures: ["3u8gPj7eN9..."],
        message: {
          accountKeys: [
            { pubkey: "Hh89LZGs7h35y4GhZtH2PJsufzKcNFm64eX9xHxeTFFX", signer: true, writable: true },
            { pubkey: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA", signer: false, writable: false }
          ],
          instructions: [
            {
              programId: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
              data: "3Bxs4tY...",
              accounts: ["Hh89LZGs7h35y4GhZtH2PJsufzKcNFm64eX9xHxeTFFX"]
            }
          ],
        }
      },
      meta: {
        err: null,
        fee: 5000,
        preBalances: [10000000, 0],
        postBalances: [9999500, 0]
      }
    },
    {
      slot: 12345679,
      transaction: {
        signatures: ["2hKkPj7eN9..."],
        message: {
          accountKeys: [
            { pubkey: "Hh89LZGs7h35y4GhZtH2PJsufzKcNFm64eX9xHxeTFFX", signer: true, writable: true },
            { pubkey: "11111111111111111111111111111111", signer: false, writable: false }
          ],
          instructions: [
            {
              programId: "11111111111111111111111111111111",
              data: "A1B2C3D4...",
              accounts: ["Hh89LZGs7h35y4GhZtH2PJsufzKcNFm64eX9xHxeTFFX"]
            }
          ],
        }
      },
      meta: {
        err: null,
        fee: 5000,
        preBalances: [9999500, 0],
        postBalances: [9999000, 0]
      }
    }
  ];
}

(async () => {
  console.log('🔍 ChainWatch AI Starting...');

  if (argv.wallet) {
    console.log(`📦 Tracing Wallet: ${argv.wallet}`);
    const txs = argv.test ? mockTransactions() : await fetchRecentTransactions(argv.wallet);
    const analysis = await analyzeWithLLM(txs);
    console.log('LLM Analysis:', analysis);
  } else {
    console.log('No wallet address provided. Use --wallet <address>');
  }
})();